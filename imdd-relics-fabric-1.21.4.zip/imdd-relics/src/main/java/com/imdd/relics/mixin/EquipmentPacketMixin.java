package com.imdd.relics.mixin;

import com.imdd.relics.RelicsMod;
import com.mojang.datafixers.util.Pair;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.s2c.play.EntityEquipmentUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

/**
 * Relíquia da Invisibilidade: quem usa a relíquia tem a armadura "apagada"
 * nos pacotes de equipamento enviados para os OUTROS jogadores.
 */
@Mixin(EntityEquipmentUpdateS2CPacket.class)
public abstract class EquipmentPacketMixin {

    @Inject(method = "<init>(ILjava/util/List;)V", at = @At("RETURN"), require = 0)
    private void imdd$hideArmor(int id, List<Pair<EquipmentSlot, ItemStack>> list, CallbackInfo ci) {
        if (!RelicsMod.HIDDEN_ARMOR.contains(id)) return;
        EntityEquipmentUpdateS2CPacket self = (EntityEquipmentUpdateS2CPacket) (Object) this;
        List<Pair<EquipmentSlot, ItemStack>> l = self.getEquipmentList();
        try {
            l.replaceAll(p -> p.getFirst().getType() == EquipmentSlot.Type.HUMANOID_ARMOR
                    ? Pair.of(p.getFirst(), ItemStack.EMPTY) : p);
        } catch (UnsupportedOperationException ignored) {
        }
    }
}
