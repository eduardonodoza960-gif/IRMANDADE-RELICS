package com.imdd.relics;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/** Menu 3x9 "IMDD» Relíquia" (só no servidor). Clicar numa relíquia entrega uma cópia. */
public final class RelicMenu extends GenericContainerScreenHandler {
    private static final int MENU_SLOTS = 27;

    /** "IMDD»" em roxo (como no chat e no título do menu). */
    public static Text prefix() {
        return Text.empty()
                .append(Text.literal("IMDD").setStyle(Style.EMPTY.withColor(0x8241D8).withBold(true)))
                .append(Text.literal("» ").setStyle(Style.EMPTY.withColor(0xAAAAAA).withBold(false)));
    }

    private static final Text TITLE = Text.empty()
            .append(prefix())
            .append(Text.literal("Relíquia").setStyle(Style.EMPTY.withBold(false)));

    private final Inventory menuInv;

    private RelicMenu(int syncId, PlayerInventory playerInv, Inventory menuInv) {
        super(ScreenHandlerType.GENERIC_9X3, syncId, playerInv, menuInv, 3);
        this.menuInv = menuInv;
    }

    public static void open(ServerPlayerEntity player) {
        SimpleInventory inv = new SimpleInventory(MENU_SLOTS);
        List<Relic> all = Relics.ALL;
        for (int i = 0; i < all.size() && i < MENU_SLOTS; i++) {
            inv.setStack(i, all.get(i).createStack(player.getRegistryManager()));
        }
        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (syncId, playerInv, p) -> new RelicMenu(syncId, playerInv, inv), TITLE));
    }

    @Override
    public void onSlotClick(int slotIndex, int button, SlotActionType actionType, PlayerEntity player) {
        if (slotIndex >= 0 && slotIndex < MENU_SLOTS) {
            if (player instanceof ServerPlayerEntity sp
                    && (actionType == SlotActionType.PICKUP || actionType == SlotActionType.QUICK_MOVE)) {
                Relic relic = Relics.of(menuInv.getStack(slotIndex));
                if (relic != null) giveRelic(sp, relic);
            }
            syncState();
            return;
        }
        if (actionType == SlotActionType.QUICK_MOVE || actionType == SlotActionType.PICKUP_ALL) {
            syncState();
            return;
        }
        super.onSlotClick(slotIndex, button, actionType, player);
    }

    @Override
    public ItemStack quickMove(PlayerEntity player, int slot) {
        return ItemStack.EMPTY;
    }

    @Override
    public boolean canInsertIntoSlot(Slot slot) {
        return slot.inventory != menuInv;
    }

    @Override
    public boolean canInsertIntoSlot(ItemStack stack, Slot slot) {
        return slot.inventory != menuInv;
    }

    private static void giveRelic(ServerPlayerEntity player, Relic relic) {
        if (hasRelic(player, relic)) {
            player.sendMessage(Text.empty().append(prefix())
                    .append(Text.literal("Você já possui essa relíquia.").formatted(Formatting.GRAY)), false);
            return;
        }
        ItemStack stack = relic.createStack(player.getRegistryManager());
        ItemStack shown = stack.copy();
        if (!player.getInventory().insertStack(stack)) {
            player.dropItem(stack, false);
        }
        // Mensagem igual à do vídeo: "IMDD» Você pegou a relíquia: Relíquia do X"
        player.sendMessage(Text.empty().append(prefix())
                .append(Text.literal("Você pegou a relíquia: " + relic.name())), false);
        player.getServerWorld().playSound(null, player.getBlockPos(),
                SoundEvents.ENTITY_ITEM_PICKUP, SoundCategory.PLAYERS, 0.5f, 1.0f);
    }

    private static boolean hasRelic(ServerPlayerEntity player, Relic relic) {
        PlayerInventory inv = player.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            if (Relics.of(inv.getStack(i)) == relic) return true;
        }
        return false;
    }
}
